# Authors & Acknowledgments

Tabula was originally started by Manuel Aristarán in late 2012.

The PRIMARY AUTHORS are (and/or have been):

* Manuel Aristarán - MIT Media Lab (formerly La Nación, Knight-Mozilla OpenNews)
* Mike Tigas - ProPublica, Knight-Mozilla OpenNews
* Jeremy B. Merrill - The New York Times (formerly ProPublica)
* Jason Das, designer <http://jasondas.com>
* David Frackman
* Travis Swicegood - Texas Tribune

Special thanks to these organizations:

* Knight-Mozilla OpenNews <https://opennews.org/>
* ProPublica <http://propublica.org>
* La Nación <http://www.lanacion.com.ar>
* The New York Times <http://www.nytimes.com>
* Knight Lab at Northwestern University <http://knightlab.northwestern.edu/>
* The John S. and James L. Knight Foundation <http://www.knightfoundation.org/>
